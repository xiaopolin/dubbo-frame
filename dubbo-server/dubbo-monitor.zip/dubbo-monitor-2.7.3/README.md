# dubbo-monitor-2.7.3
针对dubbo2.7.3服务的监控

因为阿里只提供了对dubbo2.6.0版本服务的dubbo-monitor监控, 故在此之上进行了部分修改, 对我司2.7.3的服务进行监控及调用次数进行统计等

支持同时监控多个注册中心


效果截图:

服务列表：
![image](https://aresxue.github.io/dubbo-monitor-2.7.3/src/main/resources/image/%E6%9C%8D%E5%8A%A1%E5%88%97%E8%A1%A8.png)
服务查询:
![image](https://aresxue.github.io/dubbo-monitor-2.7.3/src/main/resources/image/%E6%9C%8D%E5%8A%A1%E6%9F%A5%E8%AF%A2.png)
调用次数查看：
![image](https://aresxue.github.io/dubbo-monitor-2.7.3/src/main/resources/image/%E8%B0%83%E7%94%A8%E6%AC%A1%E6%95%B0.png)
调用次数图表：
![image](https://aresxue.github.io/dubbo-monitor-2.7.3/src/main/resources/image/%E8%B0%83%E7%94%A8%E5%9B%BE%E8%A1%A8.png)


作者: Ares

邮箱: xuebing3@asiainfo.com
