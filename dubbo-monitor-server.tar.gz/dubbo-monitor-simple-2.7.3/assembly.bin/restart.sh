#!/bin/bash
cd `dirname $0`
./stop.sh
./start.sh
